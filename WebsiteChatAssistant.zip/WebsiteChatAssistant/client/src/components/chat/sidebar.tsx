import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, MessageCircle, User, Clock } from "lucide-react";
import { chatApi } from "@/lib/chat-api";
import { useToast } from "@/hooks/use-toast";
import type { ChatConversation } from "@/types/chat";

interface SidebarProps {
  conversations: ChatConversation[];
  currentConversation: ChatConversation | null;
  isLoading: boolean;
}

export default function Sidebar({ conversations, currentConversation, isLoading }: SidebarProps) {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createConversationMutation = useMutation({
    mutationFn: () => chatApi.createConversation({ title: "Percakapan Baru" }),
    onSuccess: async (response) => {
      const newConversation = await response.json();
      await queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      setLocation(`/chat/${newConversation.id}`);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Gagal membuat percakapan baru",
        variant: "destructive"
      });
    }
  });

  const formatDate = (dateString: string | Date) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);

    if (hours < 1) return "Baru saja";
    if (hours < 24) return `${hours} jam yang lalu`;
    if (days === 1) return "1 hari yang lalu";
    if (days < 7) return `${days} hari yang lalu`;
    return date.toLocaleDateString('id-ID');
  };

  const getConversationStatus = (conversation: ChatConversation) => {
    const now = new Date();
    const updated = new Date(conversation.updatedAt);
    const diff = now.getTime() - updated.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return "neon-green";
    if (hours < 24) return "neon-amber";
    return "gray-400";
  };

  return (
    <div className="w-64 bg-[var(--dark-surface)] border-r border-[var(--neon-cyan)]/20 flex flex-col">
      {/* Header */}
      <div className="p-3 border-b border-[var(--neon-cyan)]/20">
        <Button 
          onClick={() => createConversationMutation.mutate()}
          disabled={createConversationMutation.isPending}
          className="w-full gradient-bg text-[var(--dark-bg)] font-medium hover:shadow-lg hover:shadow-[var(--neon-cyan)]/25 transition-all duration-300 rounded-lg py-3"
        >
          <Plus className="w-4 h-4 mr-2" />
          Chat Baru
        </Button>
      </div>

      {/* Conversation History */}
      <div className="flex-1 overflow-y-auto scrollbar-neon px-2 py-2">
        <div className="space-y-1">
          
          {isLoading ? (
            <div className="space-y-1">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="p-3 rounded-lg bg-[var(--dark-bg)]/30 animate-pulse">
                  <div className="h-4 bg-gray-600 rounded mb-1"></div>
                  <div className="h-3 bg-gray-700 rounded w-1/2"></div>
                </div>
              ))}
            </div>
          ) : conversations.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <MessageCircle className="w-6 h-6 mx-auto mb-3 opacity-50" />
              <p className="text-sm">Belum ada chat</p>
            </div>
          ) : (
            conversations.map((conversation) => (
              <Link
                key={conversation.id}
                href={`/chat/${conversation.id}`}
                className={`block p-3 rounded-lg transition-all duration-200 cursor-pointer group ${
                  currentConversation?.id === conversation.id
                    ? 'bg-[var(--neon-cyan)]/10 border-l-2 border-[var(--neon-cyan)]'
                    : 'hover:bg-[var(--dark-bg)]/30'
                }`}
              >
                <div className="flex items-center gap-3">
                  <MessageCircle className="w-4 h-4 text-gray-400 group-hover:text-[var(--neon-cyan)] transition-colors flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate font-normal">
                      {conversation.title}
                    </p>
                  </div>
                </div>
              </Link>
            ))
          )}
        </div>
      </div>

      {/* Bottom Section */}
      <div className="p-3 border-t border-[var(--neon-cyan)]/20">
        <div className="text-center">
          <h2 className="text-lg font-bold text-[var(--neon-cyan)] animate-pulse-neon mb-1">
            xXzZyyAI
          </h2>
          <p className="text-xs text-gray-500">by ejaa[xXzZyy]</p>
        </div>
      </div>
    </div>
  );
}
